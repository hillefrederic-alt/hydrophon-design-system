// CommonJS entry point
const tokens = require('./json/tokens.json');
module.exports = tokens;
module.exports.default = tokens;
