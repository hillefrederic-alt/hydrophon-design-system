# Hydrophon Design System v1.0.0

Hydrophon Logo-Assets in SVG und PNG Formaten fuer alle Marken (Hydrophon, Gluy, HyHero, HyIndustry).

## Inhalt

- svg
- png
- README-LOGOS.md

## Installation

Siehe die jeweiligen README-Dateien in den einzelnen Verzeichnissen für spezifische Installationsanleitungen.

## Lizenz

Dieses Design-System ist ausschliesslich zur Verwendung durch Hydrophon AG und autorisierte Partner bestimmt.

## Kontakt

Bei Fragen zum Design-System wenden Sie sich bitte an das Hydrophon Marketing-Team.

---
*Generiert am 2026-01-29*
