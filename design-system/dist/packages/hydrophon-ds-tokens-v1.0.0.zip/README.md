# Hydrophon Design System v1.0.0

Hydrophon Design Tokens in CSS, SCSS und JSON Formaten fuer die Integration in Entwicklungsprojekte.

## Inhalt

- css
- scss
- json
- package.json
- index.js
- index.cjs
- README.md

## Installation

Siehe die jeweiligen README-Dateien in den einzelnen Verzeichnissen für spezifische Installationsanleitungen.

## Lizenz

Dieses Design-System ist ausschliesslich zur Verwendung durch Hydrophon AG und autorisierte Partner bestimmt.

## Kontakt

Bei Fragen zum Design-System wenden Sie sich bitte an das Hydrophon Marketing-Team.

---
*Generiert am 2026-01-29*
