# Hydrophon Design System v1.0.0

Hydrophon Design System Dokumentation als PDF plus Farbpaletten fuer Adobe und GIMP.

## Inhalt

- documentation
- palettes

## Installation

Siehe die jeweiligen README-Dateien in den einzelnen Verzeichnissen für spezifische Installationsanleitungen.

## Lizenz

Dieses Design-System ist ausschliesslich zur Verwendung durch Hydrophon AG und autorisierte Partner bestimmt.

## Kontakt

Bei Fragen zum Design-System wenden Sie sich bitte an das Hydrophon Marketing-Team.

---
*Generiert am 2026-01-29*
